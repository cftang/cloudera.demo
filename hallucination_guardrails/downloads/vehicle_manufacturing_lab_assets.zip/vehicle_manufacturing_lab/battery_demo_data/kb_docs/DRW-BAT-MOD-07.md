# 模组支架工程图 PART-2026-BAT-MOD-07

- doc_id: DRW-BAT-MOD-07
- classification: AUTHORITATIVE
- source_type: PDF
- created_date: 2026-05-10 09:05:00
- ocr_processed: false
- tags: drawing, bracket, 3D
- source_uri: ofs://ozone/kb/PART-2026-BAT-MOD-07_drawing.pdf

## Content

模组支架工程图,材料 6061-T6,散热面积 182.4 cm²。
