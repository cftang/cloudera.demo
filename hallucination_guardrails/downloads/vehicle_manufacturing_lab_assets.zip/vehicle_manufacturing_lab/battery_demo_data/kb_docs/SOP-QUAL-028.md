# 动力电池质量异常处置 SOP §3.1

- doc_id: SOP-QUAL-028
- classification: AUTHORITATIVE
- source_type: PDF
- created_date: 2025-09-15 09:30:00
- ocr_processed: false
- tags: quality, SOP, batch
- source_uri: ofs://ozone/kb/SOP-QUAL-028.pdf

## Content

同一电芯批次 EOL 一致性异常≥2 起或异常率>3% 时须暂停使用并隔离在制与库存。
