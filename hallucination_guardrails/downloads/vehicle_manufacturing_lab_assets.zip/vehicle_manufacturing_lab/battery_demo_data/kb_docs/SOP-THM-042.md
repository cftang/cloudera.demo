# 动力电池热管理异常处置指南 §4.2

- doc_id: SOP-THM-042
- classification: AUTHORITATIVE
- source_type: PDF
- created_date: 2025-11-02 10:00:00
- ocr_processed: false
- tags: thermal, SOP, disposition
- source_uri: ofs://ozone/kb/SOP-THM-042.pdf

## Content

模组温升异常应立即隔离对应批次并复检在制模组。
