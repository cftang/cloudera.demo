# Battery Quality Prediction Tool

Agent Studio Custom Tool (`battery-prediction-tool`) — a thin HTTP client that calls the deployed
**Battery Quality Prediction Service** (the CAI Application in `../battery_model/`). It does **not**
load models itself, so it stays lightweight.

## Register in Agent Studio
**Tools → Create Custom Tool → point at `tool.py`.**
- `UserParameters.endpoint_url` → the deployed app URL
- `UserParameters.api_key` → CML workload/API Bearer token (required — the app is deployed with
  authentication; see `../battery_model/deploy_app.py`)

## Actions
- `predict_quality` → `POST /predict` — returns defect_rate / risk_level / anomaly_score / confidence
- `health_check` → `GET /health`

## Why its own folder
`tool.py` only needs `requests` + `pydantic` (see `requirements.txt`). Keeping it separate from
`../battery_model/` (fastapi + scikit-learn + xgboost …) means registering the tool doesn't drag in
the whole model-serving stack.

## Local smoke test
```bash
python tool.py --user-params '{"endpoint_url":"http://localhost:8080"}' \
  --tool-params '{"action":"predict_quality","machine_id":"PACK-07","process_type":"module_assembly",
                  "temperature":32.2,"temperature_delta":3.9,"voltage_std":0.021,"press_force":3.05,
                  "dcr":0.86,"cell_lot":"LOT-2026-0619"}'
```
