# Guardrail Tools for Agent Studio (Lab 04)

Agent Studio **Custom Tools** that turn Lab 04's thesis from prompt instructions into
enforceable, callable tools. Each folder is a standalone tool (`tool.py` +
`requirements.txt` + `README.md`, some also bundle config/data) following the Agent Studio
contract (`UserParameters` / `ToolParameters` / `run_tool` / `--user-params` `--tool-params`
entrypoint).

## Prevention layer (runs before the query)

| Tool | Layer | Agent (boundary) | Type | Prevents |
|---|---|---|---|---|
| [`ontology_grounding`](./ontology_grounding) | **prevention** semantic grounding | Data Analyst (Agent 3) | deterministic (config-driven) | wrong-entity / misread-term hallucination — resolves to a canonical `part_number` + property and emits a constrained SELECT against a governed view (never executes SQL) |

The ontology (TBox) is a bundled, git-versioned `ontology.yaml`; override it with an external
governed TBox via `UserParameters.ontology_config_path` (absolute path). See
[`ontology_grounding/README.md`](./ontology_grounding/README.md).

## Verification layer (the four G1–G4 rails)

| Tool | Guardrail | Agent (boundary) | Type | Blocks |
|---|---|---|---|---|
| [`g1_verdict_lock`](./g1_verdict_lock) | **G1** verdict ownership | Triage (Agent 2) | deterministic | LLM overriding the ML `severity`/`defect_type` |
| [`g2_claim_citation`](./g2_claim_citation) | **G2** claim citation | Investigator (Agent 4) | deterministic rule | unsourced / uncitable claims |
| [`g3_grounding_verifier`](./g3_grounding_verifier) | **G3** grounding verifier | Verifier (Agent 5) | rule (`local`) / model (`api`) | claims not backed by authoritative, released evidence → sets `response_policy` |
| [`g4_action_catalog`](./g4_action_catalog) | **G4** action catalog | Report (Agent 6) | deterministic | action codes not in the approved MES catalog |

## Design notes

- **Prevention vs. verification.** G3 is the verification centrepiece (evidence sufficiency +
  grounding, drives cite/partial/conflict/abstain). G1/G2/G4 are cheap deterministic clamps at
  their own boundaries. See [`../PROPOSAL.en.md`](../PROPOSAL.en.md).
- **Selective, not per-token.** Each tool fires at exactly one boundary (after ML verdict,
  after drafting claims, after synthesis, before actions) — controlling cost.
- **POC config vs. production governance.** Allowlists/catalogs are `UserParameters` literals for
  the POC. In the pilot/production stages they are sourced from the governed layer:
  G3's `authoritative_prefixes`/`released_docs` ← **Atlas** classifications + **Iceberg** effective
  dates; G4's `mes_action_catalog` ← the governed MES catalog; G3 `mode='api'` ← a hosted grounding
  model on **Cloudera AI Inference**.
- **`ontology.yaml` is the single source of truth** for `authoritative_prefixes` / `generic_prefixes`.
  G3 duplicates those literals for the POC (with a code comment pointing here); in the pilot G3
  reads them from the same ontology config.

## Register in Agent Studio

For each tool: **Tools → Create Custom Tool → point at `tool.py`**, then set `UserParameters`
(defaults work for the POC). Attach the tool to its agent's tool list (see Lab 04 Step 4).

## Run the CLI self-tests

```bash
cd ontology_grounding   && python tool.py --user-params '{}' --tool-params '{"entity":"MOD-07","term":"material","context":"MES"}'   # resolve + emit constrained SELECT
cd ../ontology_grounding && python tool.py --user-params '{}' --tool-params '{"term":"stock"}'   # → ambiguous=true (Case C)
cd ../g1_verdict_lock   && python tool.py --user-params '{}' --tool-params '{"ml_output":{"risk_level":"HIGH","defect_type":"thermal_anomaly"},"proposed_severity":"LOW"}'
cd ../g2_claim_citation && python tool.py --user-params '{}' --tool-params '{"claims":[{"claim":"x","source_ids":[]}]}'
cd ../g3_grounding_verifier && python tool.py --user-params '{"mode":"local"}' --tool-params '{"claims":[{"claim":"x","source_ids":["DOC-GEN-007"]}],"evidence_bundle":{"authoritative_docs":["COA-0619"]}}'
cd ../g4_action_catalog && python tool.py --user-params '{}' --tool-params '{"actions":[{"action_code":"MES-ACT-999"}]}'
```
