# G1 — Verdict Lock (`g1-verdict-lock-tool`)

Deterministic guardrail. The classification verdict (`severity` / `defect_type`) may come **only**
from the ML prediction tool; the LLM cannot override it.

- **Where:** Triage agent (Agent 2), right after the ML prediction tool.
- **Type:** deterministic (no model, no network).
- **Reads:** the raw ML output JSON + (optionally) what the LLM proposes.
- **Returns:** the locked `severity`/`defect_type` and an `override_attempt` flag.

## Parameters

**UserParameters** (registration-time)

| Field | Default | Meaning |
|---|---|---|
| `allowed_severities` | `["HIGH","MEDIUM","INVESTIGATE"]` | closed set the ML tool may emit |
| `severity_field` | `risk_level` | key in ML output holding severity |
| `defect_field` | `defect_type` | key in ML output holding defect type |

**ToolParameters** (per call)

| Field | Meaning |
|---|---|
| `ml_output` | raw JSON from the ML prediction tool |
| `proposed_severity` | (optional) severity the LLM wants to state |
| `proposed_defect_type` | (optional) defect type the LLM wants to state |
| `action_on_block` | `return_verdict` (default) or `raise_error` |

## CLI self-test

```bash
python tool.py \
  --user-params '{}' \
  --tool-params '{"ml_output":{"risk_level":"HIGH","defect_type":"thermal_anomaly"},"proposed_severity":"LOW"}'
# → verdict OVERRIDE_BLOCKED, severity stays "HIGH", override_attempt true
```
