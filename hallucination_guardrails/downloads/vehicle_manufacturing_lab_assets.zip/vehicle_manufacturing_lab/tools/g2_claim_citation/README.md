# G2 — Claim Citation (`g2-claim-citation-tool`)

Deterministic guardrail. Every root-cause claim must cite something citable — an
authoritative doc clause, a queried data row, or a named metric. Unsourced claims are
flagged non-compliant.

- **Where:** Root-Cause Investigator agent (Agent 4), after drafting `claims[]`.
- **Type:** deterministic rule (regex; no model, no network).
- **Scope:** a *shape* check (does each claim cite something), **not** a grounding check
  (whether the evidence actually supports the claim) — that is G3.

## Parameters

**UserParameters**

| Field | Default | Meaning |
|---|---|---|
| `citation_patterns` | doc-clause / `:row_N` / `metric=` regexes | a source_id is valid if it matches any |
| `min_sources` | `1` | minimum valid citations per claim |

**ToolParameters**

| Field | Meaning |
|---|---|
| `claims` | claim-contract list `[{claim, source_ids, confidence}]` |
| `action_on_block` | `return_verdict` (default) or `raise_error` |

## CLI self-test

```bash
python tool.py --user-params '{}' --tool-params '{"claims":[
  {"claim":"DCR near spec ceiling","source_ids":["COA-0619 §4.2"]},
  {"claim":"root cause is gas contamination","source_ids":[]}
]}'
# → all_compliant false; the second claim is non_compliant ("no source_ids")
```
