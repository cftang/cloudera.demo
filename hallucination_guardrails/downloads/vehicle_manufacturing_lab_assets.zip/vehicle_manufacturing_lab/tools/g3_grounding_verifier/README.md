# G3 — Grounding Verifier (`g3-grounding-verifier-tool`)

Judges each claim (supported / partial / conflicting / unsupported) against authoritative
evidence and sets the workflow `response_policy`. Sees only atomic claims + independent
evidence (not upstream prose) to avoid confirmation bias.

- **Where:** Grounding Verifier agent (Agent 5).
- **Type:** `local` deterministic rule (POC) **or** `api` hosted grounding model (production).

## Modes

| Mode | Use | Behaviour |
|---|---|---|
| `local` | POC | rule check: authoritative-prefix + released → can support; `DOC-GEN-*` / unsourced / stale → unsupported |
| `api` | production | `POST {claims, evidence_bundle}` to `verifier_endpoint`/verify on Cloudera AI Inference; verdicts passed through |

## Parameters

**UserParameters**

| Field | Default | Meaning |
|---|---|---|
| `mode` | `local` | `local` or `api` |
| `authoritative_prefixes` | `["SOP-","COA-","ECN-","DRW-","SPEC-","WPS-"]` | which source_ids count as authoritative |
| `generic_prefixes` | `["DOC-GEN-"]` | distractor prefixes → unsupported |
| `require_released` | `true` | authoritative doc must also be in `released_docs`/`authoritative_docs` |
| `verifier_endpoint` / `verifier_api_key` | `null` | AI Inference endpoint (mode=`api`) |

**ToolParameters**

| Field | Meaning |
|---|---|
| `claims` | `[{claim, source_ids, confidence}]` |
| `evidence_bundle` | `{authoritative_docs[], released_docs[], conflicts[[a,b]], needs_clarification}` |
| `action_on_block` | `return_verdict` (default) or `raise_error` |

## response_policy aggregation

`any conflicting → present_conflict` · `all supported → answer_with_citations` ·
`some supported/partial → answer_supported_only` · `none → abstain`.
`needs_clarification=true` short-circuits to `abstain`.

## CLI self-test

```bash
python tool.py --user-params '{"mode":"local"}' --tool-params '{
  "claims":[{"claim":"PACK-11 spread caused by X","source_ids":["DOC-GEN-007"],"confidence":0.7}],
  "evidence_bundle":{"authoritative_docs":["SOP-THM-042","COA-0619"]}}'
# → verdict unsupported, response_policy "abstain" (Lab Case B)
```
