# G4 — Action Catalog (`g4-action-catalog-tool`)

Deterministic guardrail. Every disposition `action_code` must exist in the approved MES
action-code catalog; invented/free-form codes are rejected. Valid actions are returned with
their canonical catalog description.

- **Where:** Report agent (Agent 6), before writing the work-order `actions[]`.
- **Type:** deterministic (no model, no network).

## Parameters

**UserParameters**

| Field | Default | Meaning |
|---|---|---|
| `mes_action_catalog` | `{MES-ACT-001: Quarantine batch, MES-ACT-007: Hold module for deep test, MES-ACT-012: Notify line supervisor}` | approved code → canonical description |

**ToolParameters**

| Field | Meaning |
|---|---|
| `actions` | proposed actions `[{action_code, description?}]` (only `action_code` is trusted) |
| `action_on_block` | `return_verdict` (default) or `raise_error` |

## CLI self-test

```bash
python tool.py --user-params '{}' --tool-params '{"actions":[
  {"action_code":"MES-ACT-001"},
  {"action_code":"MES-ACT-999"}
]}'
# → all_valid false; MES-ACT-001 valid (with description); MES-ACT-999 invalid
```
