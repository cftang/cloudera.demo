# Ontology Grounding (`ontology-grounding-tool`)

The **prevention layer** (proposal §3): runs *before* the agent queries data. Resolves a
colloquial entity to a canonical `part_number`, disambiguates a colloquial term to a canonical
property in the current business context, and emits a **constrained query_plan** — a
parameterised SELECT against a governed semantic view, always filtered to `status='RELEASED'`.

- **Where:** Data Analyst agent (Agent 3), ahead of `nl-to-sql-tool` (Lab 04 Step 2).
- **Never executes SQL.** It emits a SELECT; `nl-to-sql-tool` / `iceberg-mcp-server` runs it.
- **Deterministic.** Alias-map resolution + context-keyed disambiguation — no LLM, no network.

## How the ontology (TBox) is passed in

Two ways, both via the single `ontology_config_path` UserParameter:

1. **Bundled default (relative path).** The git-versioned [`ontology.yaml`](./ontology.yaml) ships
   in this tool folder; Agent Studio deep-copies the whole tool directory into the workflow. At
   runtime the subprocess runs with `cwd=<workflow_dir>` (not this folder), so a relative path is
   anchored on `Path(__file__).parent` — a bare `open("ontology.yaml")` would miss.
2. **Uploaded file (absolute path) — recommended for a real / editable ontology.** Agent Studio
   runs inside a CML project (`/home/cdsw`). Upload your `ontology.yaml` into the project via the
   **CML Files browser** or **JupyterLab** (e.g. to `studio-data/ontologies/ontology.yaml`), then
   set `ontology_config_path` to its absolute path, e.g.
   `/home/cdsw/studio-data/ontologies/ontology.yaml`. Edit the file in place to update the TBox —
   no tool edit, no redeploy. Keep it **outside** the tool folder so a tool update (which
   re-copies the folder) can't overwrite it.

Agent Studio's tool UI only edits `tool.py` + `requirements.txt` + the UserParameters form — it
has no per-tool file upload, so the CML project filesystem is where uploaded artefacts live.

## Parameters

**UserParameters** (registration-time)

| Field | Default | Meaning |
|---|---|---|
| `ontology_config_path` | `ontology.yaml` | Relative → bundled TBox beside `tool.py`; absolute → external override |
| `database` | `iot_car_battery_db` | DB qualifying the governed views in the emitted SQL |
| `default_context` | `null` | Fallback context (`ERP`/`WMS`/`MES`) for disambiguating a polysemous term |

**ToolParameters** (per-call)

| Field | Meaning |
|---|---|
| `entity` | Colloquial entity to resolve, e.g. `MOD-07` / `module 7` |
| `term` | Colloquial term to disambiguate, e.g. `material` / `stock` |
| `context` | Business context resolving a polysemous term, e.g. `ERP`/`WMS`/`MES` |
| `question` | Optional NL question, echoed for traceability |
| `action_on_block` | `return_verdict` (default) or `raise_error` (halts on ambiguous term / unknown entity) |

## Output

```json
{
  "layer": "prevention/ontology-grounding",
  "resolved": true, "canonical_entity": "PART-2026-BAT-MOD-07",
  "canonical_property": "material_grade", "ambiguous": false,
  "target_view": "v_part_semantic",
  "query_plan": {
    "target_view": "iot_car_battery_db.v_part_semantic",
    "filters": ["part_number = 'PART-2026-BAT-MOD-07'", "status = 'RELEASED'"],
    "sql": "SELECT part_number, material_grade FROM iot_car_battery_db.v_part_semantic WHERE part_number = 'PART-2026-BAT-MOD-07' AND status = 'RELEASED'"
  }
}
```

- **Polysemous term, no context** → `ambiguous:true`, `candidates:{...}`, `query_plan:null` →
  the agent asks a clarifying question instead of guessing (Lab 04 **Case C**).
- **Unknown entity** → `resolved:false`, `query_plan:null` → do not guess; resolve via the
  registry or ask.

## `ontology.yaml` shape

- `entities` — canonical part registry + colloquial `aliases` (resolution).
- `glossary` — single-sense (`property` + `view`) or polysemous (`contexts:` map) terms.
- `views` — governed views the query_plan targets (`key_column`, `status_column`, `columns`);
  built by [`../../battery_demo_data/create_ontology_layer_battery.py`](../../battery_demo_data/create_ontology_layer_battery.py).
- `axioms` — `authoritative_prefixes` / `generic_prefixes` (single source of truth; G3 mirrors
  them for the POC), `require_status`.

## CLI self-tests

```bash
# resolve MOD-07 + material -> canonical part + SELECT vs v_part_semantic, filtered RELEASED
python tool.py --user-params '{}' --tool-params '{"entity":"MOD-07","term":"material","context":"MES"}'
# polysemous "stock" with no context -> ambiguous=true, no SQL (Case C)
python tool.py --user-params '{}' --tool-params '{"term":"stock"}'
# unknown entity -> resolved=false, no SQL
python tool.py --user-params '{}' --tool-params '{"entity":"MOD-99"}'
# external TBox override
python tool.py --user-params '{"ontology_config_path":"/abs/path/ontology.yaml"}' --tool-params '{"entity":"MOD-07"}'
```
